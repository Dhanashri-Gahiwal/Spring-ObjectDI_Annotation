package springProject;

import org.springframework.beans.factory.annotation.Autowired;

public class HumanBody {
//	field based
	@Autowired
	private HumanHeart humanHeart;

//	setter method 
	//@Autowired
//	public void setHumanHeart(HumanHeart humanHeart) {
//		this.humanHeart = humanHeart;
//	}
	
//	dependency injection constructor
//	@Autowired
	public HumanBody(HumanHeart humanHeart) {
		super();
		this.humanHeart = humanHeart;
	}
	


	public void humanMethod() {
		if(humanHeart!=null) {
			humanHeart.heartBeating();
		}
	}
}
