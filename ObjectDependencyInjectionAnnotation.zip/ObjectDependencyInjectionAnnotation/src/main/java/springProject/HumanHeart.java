package springProject;

public class HumanHeart {
	public void heartBeating() {
		System.out.println("Heart is beating");
	}
}
