package springProject;

import org.springframework.beans.factory.annotation.Autowired;

public class TextEditor {
//	field based
//	@Autowired
	private SpellCheck spellCheck;

//	setter method based
//	@Autowired
	public void setSpellCheck(SpellCheck spellCheck) {
		this.spellCheck = spellCheck;
	}
	
//	constructor based
	@Autowired
	public TextEditor(SpellCheck spellCheck) {
	super();
	this.spellCheck = spellCheck;
}



	public void checkSpell() {
		if(spellCheck!=null) {
			spellCheck.spellChecking();
		}
	}
	
}
