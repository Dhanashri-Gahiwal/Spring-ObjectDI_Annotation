package springProject;

public class SpellCheck {
	public void spellChecking() {
		System.out.println("Your spelling is correct");
	}
}
